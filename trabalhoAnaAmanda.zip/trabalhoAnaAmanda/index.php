<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/index.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="hamburger" id="hamburgerBtn">&#9776;</button>
        <div class="container-fluid">
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="login.php?register=true">Registrar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>




    <?php
    if (isset($_GET['cod']) && $_GET['cod'] == '109') {
        echo '<div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <strong>Pronto!</strong> Perfil excluido com sucesso!
        </div>';
    }
    ?>


<div class="container d-flex justify-content-center align-items-center min-vh-80">
    <div class="text-center" style="max-width: 600px; width: 100%; padding: 20px 0;">
        <h1>Bem-vindo!</h1>
        <p>Em nosso site, oferecemos cuidados especializados para um atendimento de qualidade, com serviços de
            entregas e muito mais. Agende para receber suas compras na porta da sua casa!</p>
    </div>
</div>
 
        </div>
    </div>

    <hr class="my-5">

    <footer>
        <div class="container">
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.getElementById("hamburgerBtn").addEventListener("click", function() {
            document.getElementById("drawer").classList.add("open");
        });

        document.getElementById("closeDrawer").addEventListener("click", function() {
            document.getElementById("drawer").classList.remove("open");
        });

        document.addEventListener("DOMContentLoaded", function() {
            const sections = document.querySelectorAll('.section');
            sections.forEach((section) => {
                section.classList.add('visible');
            });

            const slider = document.querySelector('.slider');
            const slides = slider.querySelectorAll('img');
            let currentSlideIndex = 0;

            const moveLeft = () => {
                slider.scrollBy({
                    left: -slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            const moveRight = () => {
                slider.scrollBy({
                    left: slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            const prevButton = document.getElementById('prev');
            const nextButton = document.getElementById('next');
            prevButton.addEventListener('click', moveLeft);
            nextButton.addEventListener('click', moveRight);

            const autoMoveSlide = () => {
                currentSlideIndex++;
                if (currentSlideIndex >= slides.length) {
                    currentSlideIndex = 0;
                }
                slider.scrollTo({
                    left: currentSlideIndex * slider.offsetWidth,
                    behavior: 'smooth'
                });
            };

            setInterval(autoMoveSlide, 5000);
        });
    </script>
</body>

</html>
