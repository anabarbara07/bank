<?php
session_start();

// Ativando a exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica se o funcionário está logado
if (!isset($_SESSION['cpfFuncionario'])) {
    header("Location: ../../login.php");
    exit();
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "12345", "royal");
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Se o funcionário aprovar ou recusar um pedido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["acao"]) && isset($_POST["cod"])) {
    $cod = intval($_POST["cod"]);
    $acao = $_POST["acao"];

    if ($acao === "aprovar") {
        $status = "Aprovado";
        // Definindo um cookie para notificar o cliente
        setcookie("notificacao", "Sua encomenda #$cod foi aprovada!", time() + 3600, "/"); // 1 hora de duração
    } elseif ($acao === "recusar") {
        $status = "Recusado";
    } else {
        $status = null;
    }

    if ($status) {
        $stmt = $conn->prepare("UPDATE encomendas SET status = ? WHERE cod = ?");
        $stmt->bind_param("si", $status, $cod);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: aprovarEncomenda.php");
    exit();
}

// Buscar pedidos pendentes
$sql = "SELECT * FROM encomendas WHERE status IS NULL";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aprovação de Encomendas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Pedidos Pendentes</h2>

        <?php if ($result->num_rows > 0) { ?>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Observação</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row["cod"] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row["nome"] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row["contato"] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row["itens"] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row["quantidade"] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row["endereco"] ?? 'N/A'); ?></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="cod" value="<?php echo intval($row["cod"] ?? 0); ?>">
                                    <button type="submit" name="acao" value="aprovar" class="btn btn-success">✅ Aprovar</button>
                                    <button type="submit" name="acao" value="recusar" class="btn btn-danger">❌ Recusar</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p class="alert alert-warning">Não há pedidos pendentes.</p>
        <?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>


