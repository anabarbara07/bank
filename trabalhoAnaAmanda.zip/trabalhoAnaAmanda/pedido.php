<?php
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "royal";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $dataEntrega = $_POST['dataEntrega'];
    $contato = $_POST['contato'];
    $itens = $_POST['itens'];
    $endereco = $_POST['endereco'];
    $horario = $_POST['horario'];
    $quantidade = $_POST['quantidade'];
    $cep = $_POST['cep'];
    $cpfCliente = $_POST['cpfCliente'];

    $sql = "INSERT INTO encomendas (dataEntrega, contato, itens, endereco, horario, quantidade, cep, cpfCliente) 
            VALUES ('$dataEntrega', '$contato', '$itens', '$endereco', '$horario', '$quantidade', '$cep', '$cpfCliente')";

    if ($conn->query($sql) === TRUE) {
        echo "Encomenda realizada com sucesso!";
    } else {
        echo "Erro: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encomendas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e3f2fd;
            text-align: center;
            color: #003366;
        }
        .container {
            width: 50%;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-top: 5px solid #0044cc;
        }
        h2 {
            color: #0044cc;
        }
        label {
            font-weight: bold;
            color: #003366;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #0044cc;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #0044cc;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: #002a80;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Faça sua Encomenda</h2>

        <!-- Exibir notificação se o cookie estiver presente -->
        <?php if (isset($_COOKIE['notificacao'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_COOKIE['notificacao']); ?>
                <?php setcookie("notificacao", "", time() - 3600, "/"); // Remove o cookie após exibir ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label>Data de Entrega:</label>
            <input type="date" name="dataEntrega" required>
            <label>Contato:</label>
            <input type="text" name="contato" required>
            <label>Itens:</label>
            <input type="text" name="itens" required>
            <label>Endereço:</label>
            <input type="number" name="quantidade" required>
            <button type="submit">Enviar Pedido</button>
        </form>
    </div>
</body>
</html>
