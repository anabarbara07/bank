<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ofertas - Clientes</title>
    <style>
        body {
            background-color: rgba(99, 129, 227, 0.87);
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .card {
            border: 1px solid #ccc;
            border-radius: 15px;
            padding: 20px;
            background-color: beige;
            position: relative;
        }
        .product-image {
            width: 150px;
            height: auto;
            text-align: center;
            margin-bottom: 10px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .valor-produto {
            font-size: 24px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="grid-container" id="container-cards"></div>

<script>
function exibirCards() {
    const cards = JSON.parse(localStorage.getItem("cards")) || [];

    const container = document.getElementById("container-cards");

    cards.forEach(card => {
        const novoCard = document.createElement('div');
        novoCard.classList.add('card');

        novoCard.innerHTML = `
            <img class="product-image" src="${card.imagem}" alt="Imagem do Produto">
            <h3>${card.nome}</h3>
            <p class="valor-produto">${card.valor}</p>
        `;

        container.appendChild(novoCard);
    });
}

exibirCards();
</script>

</body>
</html>
