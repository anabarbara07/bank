<?php
    if($_POST) {
        require_once './usersController.php';

        //$users = usersLoadAll();
        $email = $_POST['email'];
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $cep = $_POST['cep'];
        $contato = $_POST['contato'];
        $senha = $_POST['password'];

        $hash = password_hash($senha, PASSWORD_DEFAULT);

        $result = verifyUser($cpf ,$email);


        if ($result == 0) {
            // Se não existir usuário com esse CPF ou email, registra o novo usuário
            usersRegister($nome, $email, $hash, $cep, $cpf, $contato);
            header('location: /login.php');
            exit;
        } else {
            // Se já existir, redireciona com uma mensagem de erro
            header('location: /login.php?register=true&cod=172');
            exit;
        }
}
?>