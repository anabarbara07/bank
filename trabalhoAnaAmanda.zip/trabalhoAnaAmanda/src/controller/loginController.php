<?php
if ($_POST) {
    require_once './usersController.php';

    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Busca o usuário no banco de dados
    $user = usersLogin($nome, $sobrenome, $email, $senha);

  //  $funcionarioUser = funcionarioLogin($email, $cpf);

   /* if ($user && $user->num_rows > 0) {
        $userData = $user->fetch_assoc(); //tabela usuario
        $hash = $userData['senha']; // acessa a senha hash da tabela 

        if (password_verify($senha, $hash)) {
            session_start();
            $_SESSION['cpf'] = $cpf;
            header('location: /mainPage.php');
            exit();
        } else {
            header('location: ../../login.php?cod=171');
        }
    } else if ($funcionarioUser && $funcionarioUser->num_rows > 0) {

        $funcionarioData = $funcionarioUser->fetch_assoc(); //tabela usuario
        $hash = $funcionarioData['senha']; // acessa a senha hash da tabela 

        if (password_verify($senha, $hash)) { //Senha padrão do Atendente principal: 
            session_start();
            $_SESSION['cpfFuncionario'] = $cpf;
            header('location: /mainPageFuncionario.php');
            exit();
        }
    } else {
        header('location: ../../login.php?cod=171');
    }*/
}
?>
