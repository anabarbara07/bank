<?php
include_once __DIR__ . '/../ConexaoMySql.php';

function usersRegister($nome, $sobrenome, $email, $senha)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'INSERT INTO usuarios (nome, sobrenome, email, senha) values ("' . $nome . '","' . $sobrenome . '","' . $email . '", "' . $senha .'")';

    $result = $con->Executar($sql);

    $con->Desconectar();

    return $result;
}

function usersLogin($email, $senha)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT * FROM usuarios WHERE email="' . $email . '" AND senha="' . $senha . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

function funcionarioLogin($email, $senha)
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT * FROM usuarios WHERE email="' . $email . '" AND senha="' . $senha . '"';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}

function verifyUser($cpf ,$email)
{

    $con = new ConexaoMysql();
    $con->Conectar();

    // Verificar se o CPF ou o email já estão cadastrados
    $sql = 'SELECT COUNT(*) AS total FROM usuarios WHERE email = "' . $email . '"';
    $result = $con->Consultar($sql);

    if ($result) {
        $row = $result->fetch_assoc();
        $con->Desconectar();
        
        // Se total for maior que 0, significa que já existe um usuário com esse CPF ou email
        return $row['total'] > 0 ? 1 : 0;
    }

    $con->Desconectar();
    return 0;

}

function usersFilter()
{

    $con = new ConexaoMysql();

    $con->Conectar();

    $sql = 'SELECT usuarios FROM compras';

    $result = $con->Consultar($sql);

    $con->Desconectar();

    return $result;
}


?>