<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - Admin</title>
    <style>
        body {
            background-color: rgba(99, 129, 227, 0.87);
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .card {
            border: 1px solid #ccc;
            border-radius: 15px;
            padding: 20px;
            background-color: beige;
            position: relative;
        }
        .form {
            margin-bottom: 10px;
        }
        .form-label {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
            display: block;
            margin-bottom: 5px;
        }
        .form-input {
            width: 100%;
            padding: 7px;
            font-size: 14px;
            border-radius: 5px;
        }
        .btn-adicionar {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #1E40AF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .btn-adicionar:hover {
            background-color: #163A7D;
        }
        .btn-editar, .btn-excluir, .btn-salvar {
            font-size: 14px;
            padding: 10px 20px;
            cursor: pointer;
            border: none;
            background-color: #f1f1f1;
            border-radius: 5px;
            margin-top: 15px;
        }
        .product-image {
            width: 150px;
            height: auto;
            text-align: center;
            margin-bottom: 10px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .valor-produto {
            font-size: 24px;
            text-align: center;
            font-weight: bold;
        }
        .edit-options {
            display: none;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<div class="grid-container" id="container-cards">
    <!-- Cards serão inseridos aqui -->
</div>

<button class="btn-adicionar" onclick="adicionarCard()">Adicionar outro card</button>

<script>
// Função para criar e adicionar um novo card
function adicionarCard() {
    const novoCard = document.createElement('div');
    novoCard.classList.add('card'); // Adiciona a classe card para o estilo

    // Criando ID único para cada card
    const cardId = `card-${Date.now()}`;

    // Adicionando o conteúdo do novo card
    novoCard.innerHTML = `
        <div class="card-body" id="${cardId}">

            <h2 class="card-titulo" id="nomeProduto-${cardId}">
                <strong>
                    <div class="form">
                        <label class="form-label" for="nomeProduto-${cardId}">Nome do produto:</label>
                        <input class="form-input" type="text" id="inputNomeProduto-${cardId}" placeholder="Nome do produto" />
                    </div>
                </strong>
            </h2>
                        <div class="form" id="descricaoProduto-${cardId}">
                <label class="form-label" for="descricaoProduto-${cardId}">Descrição do produto:</label>
                <input class="form-input" type="text" id="inputDescricaoProduto-${cardId}" placeholder="Descrição do produto"/>
            </div>

            <!-- Valor do produto -->
            <div class="form" id="valorProduto-${cardId}">
                <label class="form-label" for="valorProduto-${cardId}">Valor do produto:</label>
                <input class="form-input" type="number" id="inputValorProduto-${cardId}" placeholder="Valor do produto" min="0.1"/>
            </div>

            <div class="form" id="categoriaProduto-${cardId}">
                <label class="form-label" for="categoriaProduto-${cardId}">Categoria do produto:</label>
                <input class="form-input" type="text" id="inputCategoriaProduto-${cardId}" placeholder="categoria do produto" min="0.1"/>
            </div>
            <div class="form" id="quantidadeProduto-${cardId}">
                <label class="form-label" for="quantidadeProduto-${cardId}">Quantidade do produto:</label>
                <input class="form-input" type="number" id="inputQuantidadeProduto-${cardId}" placeholder="Quantidade do produto" min="0.1"/>
            </div>

            <!-- Botões -->
            <button class="btn-editar" onclick="editarCard('${cardId}')">Editar</button>
            <button class="btn-excluir" onclick="excluirCard('${cardId}')">Excluir</button>
            <button class="btn-salvar" onclick="salvarCard('${cardId}')">Salvar</button>

            <!-- Opções de edição -->
            <div class="edit-options" id="editOptions-${cardId}">
                <button onclick="editarNome('${cardId}')">Editar Nome</button>
                <button onclick="editarDescricao('${cardId}')">Editar Descrição</button>
                <button onclick="editarValor('${cardId}')">Editar Valor</button>
                <button onclick="editarCategoria('${cardId}')">Editar Categoria</button>
                <button onclick="editarQuantidade('${cardId}')">Editar Quantidade</button>
            </div>
        </div>
    `;

    // Adicionando o novo card ao container
    document.getElementById('container-cards').appendChild(novoCard);
}

// Função para salvar as edições do card
function salvarCard(cardId) {
    const nomeProdutoInput = document.getElementById(`inputNomeProduto-${cardId}`);
    const descricaoProdutoInput = document.getElementById(`inputDescricaoProduto-${cardId}`);
    const valorProdutoInput = document.getElementById(`inputValorProduto-${cardId}`);
    const categoriaProdutoInput = document.getElementById(`inputCategoriaProduto-${cardId}`);
    const quantidadeProdutoInput = document.getElementById(`inputQuantidadeProduto-${cardId}`);
    
    const nomeProduto = nomeProdutoInput.value || 'Nome do produto';
    const valorProduto = valorProdutoInput.value || 'Valor do produto';
    const descricaoProduto = descricaoProdutoInput.value || 'Descrição do produto';
    const categoriaProduto = categoriaProdutoInput.value || 'Categoria do produto';
    const quantidadeProduto = quantidadeProdutoInput.value || 'Quantidade do produto';
    

    // Cria um objeto para armazenar os dados do card
    const cardData = {
        nome: nomeProduto,
        valor: valorProduto,
        descricao: descricaoProduto,
        categoria: categoriaProduto,
        quantidade: quantidadeProduto,
    };

    // Armazena os dados no localStorage
    let cards = JSON.parse(localStorage.getItem("cards")) || [];
    cards.push(cardData);
    localStorage.setItem("cards", JSON.stringify(cards));

    // Atualiza o card com os dados salvos
    document.getElementById(`nomeProduto-${cardId}`).innerHTML = `<strong>${nomeProduto}</strong>`;
    document.getElementById(`valorProduto-${cardId}`).innerHTML = `<span class="valor-produto">${valorProduto}</span>`;

    // Esconde os inputs e exibe os dados salvos
    nomeProdutoInput.style.display = 'none';
    valorProdutoInput.style.display = 'none';
    document.getElementById(`editOptions-${cardId}`).style.display = 'block';
}

// Função para editar o nome
function editarNome(cardId) {
    const nomeProdutoInput = document.getElementById(`inputNomeProduto-${cardId}`);
    const nomeProdutoElement = document.getElementById(`nomeProduto-${cardId}`);
    const editOptions = document.getElementById(`editOptions-${cardId}`);

    // Pega o nome atual que está exibido no card (no <h2>)
    const nomeProdutoAtual = nomeProdutoElement.innerText.trim();

    // Coloca o nome atual dentro do input de nome para edição
    nomeProdutoInput.value = nomeProdutoAtual;

    // Exibe o input de nome e esconde o nome exibido
    nomeProdutoInput.style.display = 'block';  // Exibe o input de nome
    nomeProdutoElement.style.display = 'none'; // Esconde o nome exibido

    // Exibe as opções de edição (como 'Salvar', 'Cancelar', etc.)
    editOptions.style.display = 'block';

    // Foca no campo de input para o usuário começar a editar
    nomeProdutoInput.focus();
}

// Função para editar o valor do produto
function editarValor(cardId) {
    const valorProdutoInput = document.getElementById(`inputValorProduto-${cardId}`);
    const valorProdutoElement = document.getElementById(`valorProduto-${cardId}`);

    valorProdutoInput.value = valorProdutoElement.innerText; // Coloca o valor atual no input
    valorProdutoInput.style.display = 'block'; // Exibe o campo de input de valor
    valorProdutoElement.style.display = 'none'; // Esconde o valor atual

    // Exibe as opções de edição
    document.getElementById(`editOptions-${cardId}`).style.display = 'block';
    valorProdutoInput.focus(); // Foca no campo para editar
}


function excluirCard(cardId) {
    const confirmarExclusao = confirm("Tem certeza que deseja excluir este card?");

    if (confirmarExclusao) {
        const card = document.getElementById(cardId);
        card.remove();

        // Remove o card do localStorage
        let cards = JSON.parse(localStorage.getItem("cards")) || [];
        cards = cards.filter((cardData, index) => index !== parseInt(cardId.split('-')[1]));
        localStorage.setItem("cards", JSON.stringify(cards));
    }
}
</script>

</body>
</html>
